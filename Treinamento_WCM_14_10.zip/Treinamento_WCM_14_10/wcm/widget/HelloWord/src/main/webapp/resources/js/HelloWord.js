var HelloWorld = SuperWidget.extend({
    message: null,

    init: function () {
        //code
    },

    bindings: {
        local: {
            'show-message': ['click_showMessage'],
    		'show-click': ['click_btn1'],
    		'show-dblclick': ['dblclick_btn2'],
    		'show-mouseover': ["mouseover_btn3"]
        }
    },

    showMessage: function () {
        $div = $('#helloMessage_' + this.instanceId);
        $message = $('<div>').addClass('message').append(this.message);
        $div.append($message);
    },
    
    btn1: function (){
    	$('#click1').css("background-color", "green");
    },
    
    btn2: function (){
    	$('#click2').css("background-color", "red");
    },
    
    btn3: function (){
    	$('#click3').css("background-color", "yellow");
    }
    
});